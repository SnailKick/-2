import React from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Items from "./components/Items";
import Categories from "./components/Categories";
import ShowFullItem from "./components/ShowFullItem";

class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      orders: [],
      currenItems: [],
      items: [
        {
          id: 1,
          title: 'Наедине с собой. Размышление',
          img: 'onebook.jpeg',
          author: 'Марк Аврелий',
          desc: '«Наедине с собой. Размышления» – сборник афористических мыслей Марка Аврелия, написанный им на греческом языке (койне) в 70-е годы II века во время войны на дунайской границе. Он пользовался несомненным успехом в позднеантичное время, а в XVI веке возродился в европейских философских кругах.',
          category: 'AncientLiterature',
          year: '2019',
          price: '100'
        },

        {
          id: 2,
          title: 'Наедине с собой',
          img: 'twobook.jpeg',
          author: 'Марк Аврелий',
          desc: 'Современники называли Марка Аврелия праведником на троне, равного которому еще не было. Император был преисполнен глубочайшей любви к людям, смирения, доброты и великодушия. Несмотря на то что ему приходилось быть всегда на виду, вести государственные дела, участвовать в военных походах, он часто искал уединения, находя его внутри себя. Так родилась книга размышлений «Наедине с собой», которую он писал всю жизнь. Это история его души: рассуждения, отдельные мысли, советы потомкам. Попытка разобраться в себе, в сущности человеческой жизни. До сих пор темы добра и зла, смысла бытия и неизбежности смерти, поведения людей и их отношений, затронутые в книге, остаются актуальными, а интерес читателя к этому памятнику литературы Древнего Рима – неизменным.',
          category: 'AncientLiterature',
          year: '2018',
          price: '80'
        },

        {
          id: 3,
          title: 'К себе самому',
          img: 'treebook.jpeg',
          author: 'Марк Аврелий',
          desc: 'Книга римского императора и философа Марка Аврелия (121–180 гг.) – не просто мысли, обращенные к себе самому, но путь к себе, восхождение к тому идеальному образцу, по которому сотворен каждый человек. Новый перевод и комментарий придают труду знаменитого «философа на троне» дополнительную ценность.',
          category: 'AncientLiterature',
          year: '1998',
          price: '100'
        },

        {
          id: 4,
          title: 'Искажающие реальность',
          img: 'fourbook.jpeg',
          author: 'Михаил Атаманов',
          desc: 'Случившийся долгожданный Первый Контакт с инопланетной цивилизацией люди откровенно не поняли. Как и не поверило наше человечество в то, что отведённое Земле время защиты от вторжения из космоса весьма и весьма ограничено. Но после Первого Контакта осталась загадочная игра, принесённая пришельцами в наш мир. Цели этой игры туманны, сервера находятся непонятно где, да и принципы работы не поддаются объяснению.',
          category: 'CombatFantasy',
          year: '2018',
          price: '50'
        },

        {
          id: 5,
          title: 'Альянс Неудачников. Новые Боги',
          img: 'fivebook.jpeg',
          author: 'Марк Аврелий',
          desc: 'Не успели члены "Альянса Неудачников" переселиться на новое место обитания у Треглавой горы, как их убежище уже обнаружено врагами, причём как старыми, так и новыми. Затерянная меж снежных гор вечнозелёная долина является очень лакомым куском, на который сразу же зарятся соседи. А потому наступает пора Сержанта и его коту Ваське демонстрировать все умения и заклинания, которым они научились в новом мире, доставать припасённые артефакты и использовать приручённых с начала игры зверей, чтобы выдержать осаду, отбиться от яростных атак, отстоять свою независимость и жизнь. Враги сильны, и их много. Очень много. Но это даже хорошо, поскольку единства меж противниками нет, что даёт малочисленному "Альянсу Неудачников" шанс не только выстоять, но стать сильнее и достигнуть новых высот!',
          category: 'HeroicFantasy',
          year: '2023',
          price: '200'
        },

        {
          id: 6,
          title: 'Господство кланов',
          img: 'sixbook.jpeg',
          author: 'Дем Михайлов',
          desc: 'Огромный мир, наполненный приключениями и древними тайнами, чудовищами, жаждущими твоей смерти. Мир, в котором каждый может добиться исполнения своих самых заветных желаний и стать кем угодно – удачливым в делах торговцем, мудрым отшельником, отважным воином или же боевым магом, которому подвластны разрушительные стихии. Но не следует ожидать, что твой путь к исполнению мечты будет легким и безоблачным. Путь к вершине очень долог, если ты вообще до нее дойдешь.',
          category: 'CombatFantasy',
          year: '2012',
          price: '99'
        },

        {
          id: 7,
          title: 'Горе от ума',
          img: 'sevenbook.jpeg',
          author: 'Александр Грибоедов',
          desc: '«Гостиная, в ней большие часы, справа дверь в спальню Софии, откудова слышно фортопияно с флейтою, которые потом умолкают.',
          category: 'RussianClassics',
          year: '1824',
          price: '115'
        },

        {
          id: 8,
          title: 'Анна Каренина',
          img: 'eightbook.jpeg',
          author: 'Лев Толстой',
          desc: '«Анну Каренину» Толстой называл «романом широким и свободным». В основе этого определения пушкинский термин «свободный роман». Не фабульная завершенность положений, а творческая концепция определяет выбор материала и открывает простор для развития сюжетных линий. Роман «широкого дыхания» привлекал Толстого тем, что в «просторную, вместительную раму» без напряжения входило все то новое, необычайное и нужное, что он хотел сказать людям.',
          category: 'RussianClassics',
          year: '1878',
          price: '110'
        },

        {
          id: 9,
          title: 'Война и мир',
          img: 'ninebook.jpeg',
          author: 'Лев Толстой',
          desc: '«Война и мир» – роман-эпопея великого русского писателя Льва Николаевича Толстого, одно из высших достижений его художественного гения.',
          category: 'RussianClassics',
          year: '1868',
          price: '78'
        }
      ],
      showFullItem: false,
      fullItem: {}
    }
    this.state.currenItems = this.state.items
    this.addToOrder = this.addToOrder.bind(this)
    this.deleteOrder = this.deleteOrder.bind(this)
    this.chooseCategory = this.chooseCategory.bind(this)
    this.onShowItem = this.onShowItem.bind(this)
  }
  render() {
    return (
      <div className="wrapper">
        <Header orders={this.state.orders} onDelete={this.deleteOrder}/>
        <Categories chooseCategory={this.chooseCategory}/>
        <Items onShowItem={this.onShowItem} items={this.state.currenItems} onAdd={this.addToOrder}/>
        {this.state.showFullItem && <ShowFullItem onAdd={this.addToOrder} onShowItem={this.onShowItem} item= {this.state.fullItem}/>}
        <Footer/>
      </div>
    );
  }

  onShowItem(item) {
    this.setState({fullItem: item})
    this.setState({ showFullItem: !this.state.showFullItem })
  }

  chooseCategory(category) {
    if (category === 'all') {
      this.setState ({currenItems: this.state.items})
      return
    }
    this.setState({
      currenItems: this.state.items.filter(el => el.category === category)
    })
  }
  deleteOrder(id) {
    this.setState({orders: this.state.orders.filter(el => el.id !== id)})
  }

  addToOrder(item) {
    let isInArray = false
    this.state.orders.forEach(el => {
      if(el.id === item.id)
      isInArray = true
    })
    if(!isInArray)
      this.setState({orders: [...this.state.orders, item]})
  }
}

export default App;
